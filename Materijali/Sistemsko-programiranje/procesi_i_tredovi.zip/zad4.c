#include <stdio.h>
#include <pthread.h>

void* thread_function(void* arg){
	printf("Zdravo, ja sam tred!\n");
}
int main(){
	pthread_t thread;
	int status = pthread_create(&thread, NULL, thread_function, NULL);

	if(status==0){
		printf("Tred je napravljen!\n");
		pthread_join(thread, NULL);
	}else{
		printf("Tred nije napravljen!\n");
	}
	
	return 0;
}
