#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
int temp = 22;
int main(){

        pid_t pid = fork();

        if(pid==0){
                // child process;
                printf("Zdravo ja sam child proces sa ID-em %d.\n", getpid());
		sleep(10);
		temp=temp+10;
		printf("temp=%d\n", temp);
                exit(0);
        }else{
                // parent process;
                printf("Zdravo ja sam parent proces sa ID-em %d.\n", getpid());
                sleep(20);
		printf("temp=%d\n", temp);
        }

        return 0;
}
