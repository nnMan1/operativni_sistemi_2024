#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>

void signal_handler(int signal_code){
	printf("code=%d", signal_code);
	if(signal_code==SIGTERM){
		printf("Ubi me ovaj!\n");
		exit(0);
	}else{
		printf("Nepoznat kod!\n");	
	}
}
int main(){
        pid_t pid = fork();

        if(pid==0){
                // child process;
		signal(SIGTERM, signal_handler);
                printf("Zdravo ja sam child proces sa ID-em %d.\n", getpid());
                
		while(1){
			printf("Jos sam ziv...\n");
			sleep(1);
		}
		
        }else{
                // parent process;
                printf("Zdravo ja sam parent proces sa ID-em %d.\n", getpid());
                
		sleep(10);

		kill(pid, SIGTERM);
        }

        return 0;
}
