#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

#define MAX_LENGTH 1024
#define MAX_ARGS 64

void read_command(char* command, char** args){
        char line[MAX_LENGTH];
        
        int cnt = read(0, line, MAX_LENGTH-1);
        if(cnt < 0){
              perror("read error");
              exit(2);
        }
        
        if(line[cnt-1]=='\n')
                line[cnt-1] = '\0';
        line[cnt] = '\0';
        
        int index = 0;
        char* token;
        
        token = strtok(line, " \t");
        while(token!=NULL){
              args[index] = token;
              index++;
              token = strtok(NULL, " \t");
        }
        args[index] = NULL;
        
        if(index==0){
            command[0] = '\0';
        }else{
            strcpy(command, args[0]);
        }
}
int main(){
        char command[MAX_LENGTH];
        char* args[MAX_ARGS];
        
        while(1){
                printf("myshell>");
                fflush(stdout);
                
                read_command(command, args);
                if(strcmp(command, "exit")==0){
                    break;
                }
                
                if(command[0]=='\0')
                    continue;
                    
                if(fork()!=0){
                      wait(NULL);
                }else{
                      if(execvp(command, args)==-1){
                            perror("command error");
                            exit(1);
                      }
                }
        }
        return 0;
}
