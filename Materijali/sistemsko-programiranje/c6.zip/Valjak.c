#include <stdio.h>
#include <math.h>
#include <pthread.h>
#include <stdlib.h>

struct omot {
    double H;
    double r;
};

void* baza(void* arg)
{
      double* r = (double*)(arg);
      
      double* baza1 = malloc(sizeof(double));
      *baza1 = (*r) * (*r) * M_PI;
      
      return (void*)baza1;
}

void* omotac(void* arg)
{
      struct omot* args = (struct omot*)(arg);
      
      double H = (*args).H;
      double r = (*args).r;
      
      double* povrsina = malloc(sizeof(double));
      *povrsina = 2 * r * M_PI * H;
      
      return (void*)(povrsina);
}

int main(int argc, char* argv[])
{
      pthread_t tread1, tread2;
      
      double r = atof(argv[1]);
  
      int status = pthread_create(&tread1, NULL, baza,(void*)(&r));
      
      if (status != 0)
      {
          perror("Prvi thread nije kreiran.\n");
          exit(1);
      }
      
      double H = atof(argv[2]);
      
      struct omot args = {H, r};
      
      status = pthread_create(&tread2, NULL, omotac, (void*)(&args));
      
      if (status != 0)
      {
          perror("Drugi thread nije kreiran.\n");
          exit(2);
      }
    
    void* base;
    pthread_join(tread1, &base);
    
    void* omotac1;
    pthread_join(tread2, &omotac1);
    
    double rezultat = *(double*)(omotac1) + 2*(*(double*)(base));
    
    printf("Rjesenje je %lf.\n", rezultat);
  
    
    return 0;
}
