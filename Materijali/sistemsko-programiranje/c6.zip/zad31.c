#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main(){
      
      if(fork()!=0){
          // parent
          wait(NULL);
      }else{
        // child
        char* args[] = {"ls", "-l", "/home/profesor/Desktop/OS", NULL};
        
        if(execvp("ls", args)==-1){
              perror("command error");
              exit(1);
        }
        /*if(execve("/bin/ls", args, NULL)==-1){
              perror("command error");
              exit(1);
        }*/
        return 0;
      }
      
      return 0;
}
