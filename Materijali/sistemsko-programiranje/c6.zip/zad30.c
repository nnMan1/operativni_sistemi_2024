#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

pthread_mutex_t db, tmp;
int num_readers = 0;

void* reader(void* arg){
      int id = *(int*) arg;
      for(int i=0; i<5; i++){
            pthread_mutex_lock(&tmp);
            if(num_readers==0){
                  pthread_mutex_lock(&db);
            }
           num_readers++;
           pthread_mutex_unlock(&tmp); 

            printf("Reader %d cita iz baze...\n", id);
            sleep(2);
            
            pthread_mutex_lock(&tmp);
            num_readers--;
            if(num_readers==0){
                pthread_mutex_unlock(&db);
            }
            pthread_mutex_unlock(&tmp); 
    }
}

void* writer(void* arg){
    for(int i=0; i<5; i++){
          pthread_mutex_lock(&db);
          printf("Writer pise u bazu...\n");
          sleep(5);
          pthread_mutex_unlock(&db);
    }
}

int main(){
      pthread_t writerId, reader1Id, reader2Id, reader3Id;
      int ids[] = {1,2,3};
      
      pthread_mutex_init(&db, NULL);
      pthread_mutex_init(&tmp, NULL);
      pthread_create(&reader1Id, NULL, reader, (void*)ids);
      pthread_create(&reader2Id, NULL, reader, (void*)(ids+1));
      pthread_create(&reader3Id, NULL, reader, (void*)&(ids[2]));
      pthread_create(&writerId, NULL, writer, NULL);
      
      pthread_join(reader1Id, NULL);
      pthread_join(reader2Id, NULL);
      pthread_join(reader3Id, NULL);
      pthread_join(writerId, NULL);
      
      pthread_mutex_destroy(&db);
      pthread_mutex_destroy(&tmp);
      
      
      return 0;

}
