#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>

int main(int argc, char* argv[]){
    
    if(mkdir(argv[1], 0755)==-1){
      perror("Greska!");
      exit(1);
    }
    
    printf("Napravljen direktorijum %s\n", argv[1]);
    return 0;
    
}
