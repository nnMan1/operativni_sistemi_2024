#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <string.h>

int main(int argc, char* argv[])
{

    if(argc!=2)
    { 
      printf("Nedovoljan broj argumenata");
      exit(1);
    }
    
    DIR* dir = opendir(argv[1]);
    
    struct dirent* entry;
    
    entry=readdir(dir);
    
    long max=0;
    char imeNajveceg[250];
    
    struct stat attr;
    while (entry!=NULL)
    { 
      if(entry->d_type== DT_REG)

      {stat(entry->d_name,&attr);
      long size=attr.st_size;
      
      if(size>max)
      {
      max=size;
      strcpy(imeNajveceg,entry->d_name);
      
      }
      }
      entry=readdir(dir);
    }
    
    printf("%s %ld", imeNajveceg, max);
    
    return 0;
    
}
