#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <sys/mman.h>

int main(){
	pid_t pid;
	
	//int shared_var = 50;
	int* shared_var;
	int sh_fd = shm_open("/my_shm", O_CREAT | O_RDWR, 0644);
	int size = sizeof(int);
	
	ftruncate(sh_fd, size);
	shared_var = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, sh_fd, 0);
	/**shared_var = 60;*/	
	pid = fork();
	if(pid < 0){
		exit(1);	
	}
	if(pid==0){
		// child
		*shared_var += 10;
		printf("Child prints shared_var = %d\n", *shared_var);
		exit(0);
	}else{
		// parent
		wait(NULL);
		printf("Parent prints shared_var = %d\n", *shared_var);
	}
	
	munmap(shared_var, size);
	shm_unlink("/my_shm");
	close(sh_fd);
	return 0;
}
