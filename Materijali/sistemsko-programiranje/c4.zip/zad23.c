#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>

int main(int argc, char* argv[]){
    
    if(rmdir(argv[1])==-1){
      perror("Greska!");
      exit(1);
    }
    
    printf("Izbrisan direktorijum %s\n", argv[1]);
    return 0;
    
}
