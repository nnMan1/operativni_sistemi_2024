#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

int main(int argc, char* argv[]){
	int fd = open(argv[1], O_RDONLY); // O_WRONLY, O_RDWR

	if(fd < 0){
		printf("Greska u otvaranju fajla!\n");
		exit(1);
	}
	char buffer[4096];
	int rd_count = read(fd, buffer, 4096);

	while(rd_count > 0){
		printf("%s", buffer);
		rd_count = read(fd, buffer, 4096);
		if(rd_count < 0) break;
	}

	if(rd_count < 0)
		exit(1);
	return 0;
}
