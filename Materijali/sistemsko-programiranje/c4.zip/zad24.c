#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>

int main(int argc, char* argv[]){
    
    if(argc!=2){
      printf("Pogresan broj argumenata!\n");
      exit(1);
    }
    
    DIR* dir = opendir(argv[1]);
    
    struct dirent* entry;
    entry = readdir(dir);
    while(entry!=NULL){
      printf("Ime fajla: %s ", (*entry).d_name);
      printf("Tip fajla: %d\n", (*entry).d_type);
      entry = readdir(dir);
    }
    
    printf("Kraj!");
    printf("DT_REG=%d\n", DT_REG);
    printf("DT_DIR=%d\n", DT_DIR);
    printf("DT_LNK=%d\n", DT_LNK);
    printf("DT_CHR=%d\n", DT_CHR);
    printf("DT_BLK=%d\n", DT_BLK);

    return 0;
}
