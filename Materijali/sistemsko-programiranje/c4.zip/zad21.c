#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>

int main(int argc, char* argv[]){
    if(argc!=2){
      printf("Pogresan broj argumenata!\n");
      exit(1);
    }
    
    struct stat attr;
    
    if(stat(argv[1], &attr)==-1){
      perror("Greska u citanju atributa");
      exit(2);
    }
    
    printf("Velicina fajla je %ld bajtova.\n",attr.st_size);
    printf("Vrijeme poslednjeg pristupanja: %ld\n", attr.st_atime);    
    printf("Vrijeme poslednjeg modifikovanja: %ld\n", attr.st_mtime);  
    printf("Vrijeme poslednjeg pristupanja: %s\n", ctime(&attr.st_atime));
    
    
    return 0;
}
