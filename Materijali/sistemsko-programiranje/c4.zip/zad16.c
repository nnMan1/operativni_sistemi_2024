#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

int main(int argc, char* argv[]){
	if(argc!=3){
		printf("Pogresan broj argumenata!\n");
		exit(1);
	}
	int fd = open(argv[1], O_RDONLY); // O_WRONLY, O_RDWR
	
	int output_fd = creat(argv[2], 0666);
	
	if(fd < 0){
		printf("Greska u otvaranju fajla!\n");
		exit(2);
	}

	if(output_fd < 0){
		printf("Greska u kreiranju fajla!\n");
		exit(5);
	}
	char buffer[4096];
	int rd_count = read(fd, buffer, 4096);

	while(rd_count > 0){
		//printf("%s", buffer);
		int wr_count = write(output_fd, buffer, rd_count);
		rd_count = read(fd, buffer, 4096);
		if(rd_count < 0) break;
	}

	if(rd_count < 0)
		exit(3);

	close(output_fd);
	close(fd);
	return 0;
}
