#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

int main(){
	int* mem;
	int n = 1000;
	int size = n*sizeof(int);
	mem = sbrk(size);
	
	for(int i=0; i<1000; i++){
		mem[i] = i*3;
	}

	for(int i=0; i<10; i++){
		printf("mem[%d]=%d\n", i, mem[i]);
	}

	sbrk(-size); // free
	return 0;

}
