#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(int argc, char* argv[]){
	
	if(argc!=3){
		printf("Pogresan broj argumenata!\n");
		exit(1);
	}

	if(symlink(argv[1], argv[2])==-1){
		perror("Error in linking a file");
		exit(2);
	}

	printf("Uspjesno napravljen shortcut izmedju %s i %s\n", argv[1], argv[2]);

	return 0;
}
