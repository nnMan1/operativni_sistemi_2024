#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

void* myfun(void* arg){
	float* fPtr = (float*) arg;
	
	printf("Vrijednost argumenta je: %f\n", *fPtr);
	float f = *fPtr;

	float* rezultat = malloc(sizeof(float));
	
	*rezultat = f*f;
	
	return rezultat;
}

int main(){
	
	pthread_t threadID;
	float pi = 3.14;
	int status = pthread_create(&threadID, NULL, myfun, (void*)&pi);
	if(status!=0){
		printf("Greska!\n");
		exit(1);
	}
	void* rezultat; 
	status = pthread_join(threadID, &rezultat);
	if(status!=0){
		printf("Greska kod join.\n");
		exit(2);
	}

	float rez = *((float *)rezultat);
	printf("Tred je izracunao %f\n", rez);

	free(rezultat);
	return 0;
}
