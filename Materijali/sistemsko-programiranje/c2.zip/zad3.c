#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>

int main(){
        pid_t pid = fork();

        if(pid==0){
                // child process;
                printf("Zdravo ja sam child proces sa ID-em %d.\n", getpid());
                
		while(1){
			printf("Jos sam ziv...\n");
			sleep(1);
		}
		
        }else{
                // parent process;
                printf("Zdravo ja sam parent proces sa ID-em %d.\n", getpid());
                
		sleep(10);

		if(kill(pid, SIGKILL)==0){
			printf("Uspjesno poslat signal!\n");
		}else{
			printf("Greska u slanju signala!\n");
		}

        }

        return 0;
}
