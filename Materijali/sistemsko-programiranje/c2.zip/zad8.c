#include <stdio.h>
#include <pthread.h>

int sharedCnt = 0;

void* threadFun(void* arg){
	sharedCnt++;
}

int main(){
	pthread_t ids[5];

	for(int i=0; i<5; i++){
		pthread_create(&ids[i], NULL, threadFun, NULL);
	}

	for(int i=0; i<5; i++){
		pthread_join(ids[i], NULL);
	}

	printf("Vrijednost promjenljive je: %d\n", sharedCnt);

	return 0;
}
