#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>

int main(){
        pid_t pid = fork();
	if(pid<0){
		printf("Greska!\n");
		exit(1);
	}

        if(pid==0){
                // child process;
		sleep(10);
                printf("Zdravo ja sam child proces sa ID-em %d.\n", getpid());
		exit(0);
        }else{
                // parent process;
		// wait(NULL);
		waitpid(pid, NULL, 0);
                printf("Zdravo ja sam parent proces sa ID-em %d.\n", getpid());
        }

        return 0;
}
