#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void* myfun(void* arg){
	int* iPtr = (int*) arg;
	int i = *iPtr; // procitati predato i iz arg...
	printf("Moj argument je %d\n", i);
	
	return NULL;
}

int main(){

	pthread_t threadID[5];
	
	for(int i=0; i<5; i++){
		int* argPtr = malloc(sizeof(int));
		*argPtr = i;
		int status = pthread_create(&threadID[i], NULL, myfun, (void *)argPtr);
		if(status != 0)
			printf("Doslo je do greske prilikom kreiranja treda!\n");
	}
	
	for(int i=0; i<5; i++)
		pthread_join(threadID[i], NULL);

	return 0;
}
