#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>

int sharedCnt = 0;
sem_t cnt_lock;

void* threadFun(void* arg){
	for(int i=0; i<10000; i++){
		//int v;
		//sem_getvalue(&cnt_lock, &v);
		//printf("sem=%d\n", v);
		sem_wait(&cnt_lock);
		sharedCnt++;
		sem_post(&cnt_lock);
	}
}

int main(){
	pthread_t ids[5];
	sem_init(&cnt_lock, 0, 1);
	for(int i=0; i<5; i++){
		pthread_create(&ids[i], NULL, threadFun, NULL);
	}

	for(int i=0; i<5; i++){
		pthread_join(ids[i], NULL);
	}

	printf("Vrijednost promjenljive je: %d\n", sharedCnt);
	sem_destroy(&cnt_lock);
	return 0;
}
