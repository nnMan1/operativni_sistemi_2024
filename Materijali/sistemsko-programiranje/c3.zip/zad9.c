#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sched.h>

void* my_thread(void* arg){
	int* idPtr = (int*) arg;
	int id = *idPtr;
	for(int i=1; i<=5; i++){
		printf("id: %d, i=%d\n", id, i);
		sched_yield();
	}
	pthread_exit(NULL);
}
int main(){
	
	pthread_t id1, id2;

	pthread_create(&id1, NULL, my_thread, (void *)&id1);
	pthread_create(&id2, NULL, my_thread, (void *)&id2);
	
	pthread_join(id1, NULL);
	pthread_join(id2, NULL);

	return 0;
	
}
