#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include <stdlib.h>

int buffer[5];
int cnt = 0;
sem_t num_empty, num_full;
pthread_mutex_t mutex;

void* producer(void* arg){

  for(int i=1; i<100; i++){
    int item = rand()%100;
    sem_wait(&num_empty);
    pthread_mutex_lock(&mutex);
    buffer[cnt] = item;
    cnt++;
    printf("Produced item: %d. Count: %d.\n", item, cnt);
    pthread_mutex_unlock(&mutex);
    sem_post(&num_full);
  }
}

void* consumer(void* arg){
  for(int i=1; i<100; i++){
    sem_wait(&num_full);
    pthread_mutex_lock(&mutex);
    int item = buffer[cnt-1];
    cnt--;
    printf("Consumed item: %d. Count:%d.\n", item, cnt);
    pthread_mutex_unlock(&mutex);
    sem_post(&num_empty);
  }
}


int main(){

  sem_init(&num_empty, 0, 5);
  sem_init(&num_full, 0, 0);
  pthread_mutex_init(&mutex, NULL);
  
  pthread_t prod, cons;
  pthread_create(&prod, NULL, producer, NULL);
  pthread_create(&cons, NULL, consumer, NULL);
    
  pthread_join(prod, NULL);
  pthread_join(cons, NULL);
  
  sem_destroy(&num_empty);
  sem_destroy(&num_full);
  pthread_mutex_destroy(&mutex);
  
  return 0;
}
