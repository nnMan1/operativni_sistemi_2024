#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define N 5
int buffer[N];
int cnt = 0;
pthread_mutex_t the_mutex;
pthread_cond_t condp, condc;

void* producer(void* arg){

  for(int i=0; i<100; i++){
    int item = rand()%100;
    
    pthread_mutex_lock(&the_mutex);
    while(cnt==N){
      pthread_cond_wait(&condp, &the_mutex);
    }
    buffer[cnt] = item;
    cnt++;
    printf("Produced item: %d. Count: %d.\n", item, cnt);
    pthread_cond_signal(&condc);
    pthread_mutex_unlock(&the_mutex);
  }
}

void* consumer(void* arg){
  for(int i=0; i<100; i++){
    pthread_mutex_lock(&the_mutex);
    while(cnt==0){
      pthread_cond_wait(&condc, &the_mutex);
    }
    int item = buffer[cnt-1];
    cnt--;
    printf("Consumed item: %d. Count:%d.\n", item, cnt);
    pthread_cond_signal(&condp);
    pthread_mutex_unlock(&the_mutex);
  }
}

int main(){
  
  pthread_t prod, cons;
  
  pthread_mutex_init(&the_mutex, NULL);
  pthread_cond_init(&condp, NULL);
  pthread_cond_init(&condc, NULL);
  
  pthread_create(&prod, NULL, producer, NULL);
  pthread_create(&cons, NULL, consumer, NULL);
  
  pthread_join(prod, NULL);
  pthread_join(cons, NULL);
  
  
  pthread_mutex_destroy(&the_mutex);
  pthread_cond_destroy(&condp);
  pthread_cond_destroy(&condc);
  
  return 0;
  
}
