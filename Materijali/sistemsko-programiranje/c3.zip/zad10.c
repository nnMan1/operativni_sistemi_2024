#include <stdio.h>
#include <pthread.h>

int sharedCnt = 0;
pthread_mutex_t cnt_lock;

void* threadFun(void* arg){
	for(int i=0; i<10000; i++){
		pthread_mutex_lock(&cnt_lock);
		sharedCnt++;
		pthread_mutex_unlock(&cnt_lock);
	}
}

int main(){
	pthread_t ids[5];
	pthread_mutex_init(&cnt_lock, NULL);
	for(int i=0; i<5; i++){
		pthread_create(&ids[i], NULL, threadFun, NULL);
	}

	for(int i=0; i<5; i++){
		pthread_join(ids[i], NULL);
	}

	printf("Vrijednost promjenljive je: %d\n", sharedCnt);
	pthread_mutex_destroy(&cnt_lock);
	return 0;
}
