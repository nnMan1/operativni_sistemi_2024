#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

struct student{
    int brIndeksa;
    char ime[50];
    float prosjek;
};

int main(){
      int fd = open("studenti.bin", O_RDONLY);
      
      struct student temp;
      int rd_count;
      
      while((rd_count=read(fd, &temp, sizeof(struct student)))>0){
              printf("Broj indeksa: %d\n", temp.brIndeksa);
              printf("Ime: %s\n", temp.ime);
              printf("Prosjek: %.2f\n", temp.prosjek);
              printf("-------------------------------\n");
      }
      
      return 0;

}
