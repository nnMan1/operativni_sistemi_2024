#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

int main(int argc, char* argv[]) {
    if(argc != 4) {
        printf("Nedovoljan broj argumenata.");
        exit(1);
    }
    
    DIR* srcDir = opendir(argv[1]);
    DIR* dstDir = opendir(argv[2]);
    
    if(srcDir == NULL) {
      perror("Nevalidan direktorijum.");
      exit(2);
    }
    
    if(dstDir == NULL) {
      perror("Nevalidan dst direktorijum.");
      exit(2);
    }
    struct dirent* srcEntry;
    while((srcEntry= readdir(srcDir)) != NULL) {
            if(srcEntry->d_type == DT_REG) {
                if(strncmp(srcEntry->d_name, argv[3], strlen(argv[3])) == 0) {
                        char srcFilePath[strlen(argv[1]) + 5 + strlen(srcEntry->d_name)];
                        strcpy(srcFilePath, argv[1]);
                        strcat(srcFilePath, "/");
                        strcat(srcFilePath, srcEntry->d_name);
                        
                        char dstFilePath[strlen(argv[2]) + 5 + strlen(srcEntry->d_name)];
                        strcpy(dstFilePath, argv[2]);
                        strcat(dstFilePath, "/");
                        strcat(dstFilePath, srcEntry->d_name);
                        
                          if(rename(srcFilePath, dstFilePath) == -1) {
                            perror("rename error");
                            exit(4);
                          }
                   }       
              }
        }
        
    
    
    return 0;
}
