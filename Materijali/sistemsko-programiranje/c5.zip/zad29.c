#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(){
      pid_t pid;
      
      int pipefd[2];
      
      if(pipe(pipefd)==-1){
            perror("pipe erorr");
            exit(1);
      }
      
      pid = fork();
      
      if(pid!=0){
            // parent
            int number = 29;
            write(pipefd[1], &number, sizeof(int));
            close(pipefd[0]);
            close(pipefd[1]);
      }else{
            // child
            int receivedNum;
            read(pipefd[0], &receivedNum, sizeof(int));
            printf("Child received a number: %d\n", receivedNum);
            close(pipefd[0]);
            close(pipefd[1]);
            
      }
      
      return 0;
}
