#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

int countChar(char* filepath, char c){
        int cnt = 0;
        int fd = open(filepath, O_RDONLY); // O_RDONLY, O_WRONLY, O_RDWR, O_CREAT
        if(fd==-1){
              perror("open error");
              exit(2);
        }
        
        char buffer[4096];
        int rd_count;
        int i;
        while((rd_count = read(fd, buffer, 4096)) >0){
                for(i=0; i<rd_count; i++){
                        if(buffer[i]==c)
                                cnt++;
                }
        }
        return cnt;
}
int main(int argc, char* argv[]){
        if(argc!=2){
                printf("Nepravilan broj argumenata!\n");
                exit(1);
        }
        
        DIR* dir = opendir(argv[1]);
        if(dir==NULL){
                perror("opendir error");
                exit(3);
        }
        struct dirent* entry;
        
        entry = readdir(dir);
        char filepath[256];
        while(entry!=NULL){
                if(entry->d_type==DT_REG){
                        strcpy(filepath, argv[1]);
                        strcat(filepath, "/");
                        strcat(filepath, entry->d_name);
                        int cnt = countChar(filepath, 'a');
                        printf("Fajl: %s, broj: %d\n", entry->d_name, cnt);
                }
                entry = readdir(dir);
        }
        
        return 0;
        
}
