#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

struct student{
    int brIndeksa;
    char ime[50];
    float prosjek;
};

int main(){
      struct student s1 = {1, "Marko Markovic", 9.5};
      struct student s2 = {5, "Ivana Ivanovic", 7.7};
      struct student s3 = {2, "Petar Petrovic", 8.2};
      
      int fd = open("studenti.bin", O_WRONLY | O_CREAT, 0777);
      if(fd<0){
          perror("open error");
          exit(1);
      }
      
      if(lseek(fd, 0, SEEK_END)==-1) // SEEK_START, SEEK_END, SEEK_CURR
      {
            perror("seek error");
            exit(3);
      }
      int wr_count = write(fd, &s1, sizeof(struct student));
      if(wr_count<0){
            perror("write error");
            exit(2);
      }

      wr_count = write(fd, &s2, sizeof(struct student));
      if(wr_count<0){
            perror("write error");
            exit(2);
      }
    
    
    lseek(fd, -2*sizeof(struct student), SEEK_END);
    write(fd, &s3, sizeof(struct student));
    
    write(fd, &s3, sizeof(struct student));
    close(fd);
    return 0;
}
